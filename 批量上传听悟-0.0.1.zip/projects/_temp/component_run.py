
import sys
import os
from common.util.recursive_util import tail_call_optimized
from common.util.decryption_util import decrypt,encryption
from common.util.get_config_util import get_config
from common.util.log_util import trace_log
from common.util.option_util import options
from common.util.elements_util import elementsFormat, elementsFormatNew, collectElementsFormat, child_ele_eval
from common.util.judge_components import *
from common.util.selector_array import get_selector_array,get_selector_array_mobile
from common.util.loop_excel import excel_loop_data
from common.util.custom_code_component_location import custom_code_start, custom_code_end, custom_code_exit
from common.util.loop_code_component_location import *
from common.util.component_public_method import str_encryption
from common.util.pdb_util import process_debug
from common.util.shared_variables import GetSharedVariable
from projects.rpaRoot import SZEnv

import packages.WebBrowser.py.exports as WebBrowser
import packages.Element.py.exports as Element
import packages.File.py.exports as File
import packages.Basic.py.exports as Basic
import packages.List.py.exports as List
import packages.Dialog.py.exports as Dialog
from ..global_data import globalVar
from ..global_data import TASK_VARIABLE_MAP
from ..global_data import MOBILE_DEVICE_MAP
from ..global_data import GLOBAL_CONFIG_PASSWORD
from ..global_data import SHIZAI_ELEMENT_DICT
from ..global_data import run_module
self = SZEnv['rpa']
    
def main(rpa, **kw):
    global Log
    点击结果 = Dialog.CsMsgBox(SZEnv['rpa'], "运行", 1, "调整好框的位置，打开好页面，点击确定运行。", 1, 0, 3, 0, 0, var_ret=0, skip_err=0, delay_before_new=0, delay_after_new=0)  #@!io5cd@!-@!ghgSV@!-@!流程块1@!-@!消息确认对话框@!-@!1@!
    文件列表 = File.GetFileList(SZEnv['rpa'], "C:\\Users\\chenliqi\\Desktop\\测试", "", "", 0, 1, var_ret=0, skip_err=0, delay_before_new=0, delay_after_new=0)  #@!io5cd@!-@!hQnUK@!-@!流程块1@!-@!获取文件列表@!-@!2@!
    loop_code_start(SZEnv['rpa'], "io5cd", "wDJS8", "logic_control_while_v2", "条件循环(while)", task_name="流程块1", component_sequence="3", variable_name="undefined", file_path=__file__) #**EXTRA_CODE_SHIZAI**
    while ("1" == "1"): #@!io5cd@!-@!wDJS8@!-@!流程块1@!-@!条件循环(while)@!-@!3@!
        loop_once_start(SZEnv['rpa'], "io5cd", "wDJS8", "logic_control_while_v2", "条件循环(while)", task_name="流程块1", component_sequence="3", variable_name="undefined", file_path=__file__) #**EXTRA_CODE_SHIZAI**
        try: #**EXTRA_CODE_SHIZAI**
            网页对象 = WebBrowser.GetTAB_V1(SZEnv['rpa'], "chrome", 2, "", "", 0, var_ret=0, skip_err=0, delay_before_new=0.2, delay_after_new=0.05, timeout_new=30)  #@!io5cd@!-@!ZbHWL@!-@!流程块1@!-@!获取网页 Tab 对象@!-@!4@!
            Element.Click_V5(SZEnv['rpa'], elementsFormatNew(SHIZAI_ELEMENT_DICT["eboaG"]["selector"]), None, 0, 0, 1, 1, {"cursorPosition": 0, "offset": {"x": 0, "y": 0}, "random": 0}, 1, skip_err=0, delay_before_new=0.2, delay_after_new=0.05, timeout_new=30)  #@!io5cd@!-@!SJV2R@!-@!流程块1@!-@!点击界面元素@!-@!5@!
            Element.Click_V5(SZEnv['rpa'], elementsFormatNew(SHIZAI_ELEMENT_DICT["nHeOJ"]["selector"]), None, 0, 0, 1, 1, {"cursorPosition": 0, "offset": {"x": 0, "y": 0}, "random": 0}, 1, skip_err=0, delay_before_new=0.2, delay_after_new=0.05, timeout_new=30)  #@!io5cd@!-@!qQeWc@!-@!流程块1@!-@!点击界面元素@!-@!6@!
            Element.Click_V5(SZEnv['rpa'], elementsFormatNew(SHIZAI_ELEMENT_DICT["aSu39"]["selector"]), None, 0, 0, 1, 1, {"cursorPosition": 0, "offset": {"x": 0, "y": 0}, "random": 0}, 1, skip_err=0, delay_before_new=0.2, delay_after_new=0.05, timeout_new=30)  #@!io5cd@!-@!maDiJ@!-@!流程块1@!-@!点击界面元素@!-@!7@!
            文件路径 = Basic.SetVariable(SZEnv['rpa'], 文件列表[0], var_ret=0)  #@!io5cd@!-@!FAo56@!-@!流程块1@!-@!设置变量@!-@!8@!
            文件列表 = List.DeleteList(SZEnv['rpa'], 文件列表, 1, 0, "A", var_ret=0, skip_err=0, delay_before_new=0, delay_after_new=0)  #@!io5cd@!-@!HQyU9@!-@!流程块1@!-@!删除列表项@!-@!9@!
            Basic.DebugOutput(SZEnv['rpa'], 文件路径)  #@!io5cd@!-@!2mqcR@!-@!流程块1@!-@!调试输出@!-@!10@!
            Element.SetValue_V5(SZEnv['rpa'], elementsFormatNew(SHIZAI_ELEMENT_DICT["cwz5P"]["selector"]), None, 文件路径, 0, 0, 0, 1, 150, 500, 0, var_ret=0, skip_err=0, delay_before_new=0.2, delay_after_new=0.05, timeout_new=30)  #@!io5cd@!-@!ZSbHh@!-@!流程块1@!-@!输入文本@!-@!11@!
            Element.Click_V5(SZEnv['rpa'], elementsFormatNew(SHIZAI_ELEMENT_DICT["HAUao"]["selector"]), None, 0, 0, 1, 1, {"cursorPosition": 0, "offset": {"x": 0, "y": 0}, "random": 0}, 1, skip_err=0, delay_before_new=0.2, delay_after_new=0.05, timeout_new=30)  #@!io5cd@!-@!sB9ue@!-@!流程块1@!-@!点击界面元素@!-@!12@!
            loop_code_start(SZEnv['rpa'], "io5cd", "ggrQt", "logic_control_count_for_v1", "计次循环(for)", task_name="流程块1", component_sequence="13", variable_name="undefined", file_path=__file__) #**EXTRA_CODE_SHIZAI**
            for 当前循环值 in range(0,39,1):  #@!io5cd@!-@!ggrQt@!-@!流程块1@!-@!计次循环(for)@!-@!13@!
                 #@!io5cd@!-@!ggrQt@!-@!流程块1@!-@!计次循环(for)@!-@!13@!
                loop_once_start(SZEnv['rpa'], "io5cd", "ggrQt", "logic_control_count_for_v1", "计次循环(for)", task_name="流程块1", component_sequence="13", variable_name="undefined", file_path=__file__) #**EXTRA_CODE_SHIZAI**
                try: #**EXTRA_CODE_SHIZAI**
                    Element.Click_V5(SZEnv['rpa'], elementsFormatNew(SHIZAI_ELEMENT_DICT["aEE3c"]["selector"]), None, 0, 0, 1, 1, {"cursorPosition": 0, "offset": {"x": 0, "y": 0}, "random": 0}, 1, skip_err=0, delay_before_new=0.2, delay_after_new=0.05, timeout_new=30)  #@!io5cd@!-@!cwzEf@!-@!流程块1@!-@!点击界面元素@!-@!14@!
                    if (len(文件列表) == 0): #@!io5cd@!-@!rDnh6@!-@!流程块1@!-@!添加条件判断(if)@!-@!15@!
                        custom_code_start(SZEnv['rpa'], "io5cd", "KTPph", "logic_control_stop", "退出流程(exit)", task_name="流程块1", component_sequence="16") #**EXTRA_CODE_SHIZAI**
                        try: #**EXTRA_CODE_SHIZAI**
                            sys.exit() #@!io5cd@!-@!KTPph@!-@!流程块1@!-@!退出流程(exit)@!-@!16@!
                        finally: #**EXTRA_CODE_SHIZAI**
                            custom_code_end(SZEnv['rpa'], "io5cd", "KTPph", "logic_control_stop", "退出流程(exit)", task_name="流程块1", component_sequence="16") #**EXTRA_CODE_SHIZAI**
                    文件路径 = Basic.SetVariable(SZEnv['rpa'], 文件列表[0], var_ret=0)  #@!io5cd@!-@!FnZJL@!-@!流程块1@!-@!设置变量@!-@!17@!
                    文件列表 = List.DeleteList(SZEnv['rpa'], 文件列表, 1, 0, "A", var_ret=0, skip_err=0, delay_before_new=0, delay_after_new=0)  #@!io5cd@!-@!WEoNB@!-@!流程块1@!-@!删除列表项@!-@!18@!
                    Basic.DebugOutput(SZEnv['rpa'], 文件路径)  #@!io5cd@!-@!dMTir@!-@!流程块1@!-@!调试输出@!-@!19@!
                    Element.SetValue_V5(SZEnv['rpa'], elementsFormatNew(SHIZAI_ELEMENT_DICT["cwz5P"]["selector"]), None, 文件路径, 0, 0, 0, 1, 150, 500, 0, var_ret=0, skip_err=0, delay_before_new=0.2, delay_after_new=0.05, timeout_new=30)  #@!io5cd@!-@!DEXZc@!-@!流程块1@!-@!输入文本@!-@!20@!
                    Element.Click_V5(SZEnv['rpa'], elementsFormatNew(SHIZAI_ELEMENT_DICT["HAUao"]["selector"]), None, 0, 0, 1, 1, {"cursorPosition": 0, "offset": {"x": 0, "y": 0}, "random": 0}, 1, skip_err=0, delay_before_new=0.2, delay_after_new=0.05, timeout_new=30)  #@!io5cd@!-@!gMgwY@!-@!流程块1@!-@!点击界面元素@!-@!21@!
                finally: #**EXTRA_CODE_SHIZAI**
                    loop_once_end(SZEnv['rpa'], "io5cd", "ggrQt", "logic_control_count_for_v1", "计次循环(for)", task_name="流程块1", component_sequence="13", variable_name="undefined", file_path=__file__) #**EXTRA_CODE_SHIZAI**
            loop_code_end(SZEnv['rpa'], "io5cd", "ggrQt", "logic_control_count_for_v1", "计次循环(for)", task_name="流程块1", component_sequence="13", variable_name="undefined", file_path=__file__) #**EXTRA_CODE_SHIZAI**
            Element.Click_V5(SZEnv['rpa'], elementsFormatNew(SHIZAI_ELEMENT_DICT["zUTIS"]["selector"]), None, 0, 0, 1, 1, {"cursorPosition": 0, "offset": {"x": 0, "y": 0}, "random": 0}, 1, skip_err=0, delay_before_new=0.2, delay_after_new=2, timeout_new=30)  #@!io5cd@!-@!Ke94f@!-@!流程块1@!-@!点击界面元素@!-@!22@!
        finally: #**EXTRA_CODE_SHIZAI**
            loop_once_end(SZEnv['rpa'], "io5cd", "wDJS8", "logic_control_while_v2", "条件循环(while)", task_name="流程块1", component_sequence="3", variable_name="undefined", file_path=__file__) #**EXTRA_CODE_SHIZAI**
    loop_code_end(SZEnv['rpa'], "io5cd", "wDJS8", "logic_control_while_v2", "条件循环(while)", task_name="流程块1", component_sequence="3", variable_name="undefined", file_path=__file__) #**EXTRA_CODE_SHIZAI**