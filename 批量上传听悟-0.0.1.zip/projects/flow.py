
import sys
import os
from common.util.recursive_util import tail_call_optimized
from common.util.decryption_util import decrypt,encryption
from common.util.get_config_util import get_config
from common.util.log_util import trace_log
from common.util.option_util import options
from common.util.elements_util import elementsFormat, elementsFormatNew, collectElementsFormat, child_ele_eval
from common.util.judge_components import *
from common.util.selector_array import get_selector_array,get_selector_array_mobile
from common.util.loop_excel import excel_loop_data
from common.util.custom_code_component_location import custom_code_start, custom_code_end, custom_code_exit
from common.util.loop_code_component_location import *
from common.util.component_public_method import str_encryption
from common.util.pdb_util import process_debug
from common.util.shared_variables import GetSharedVariable
from projects.rpaRoot import SZEnv

from .global_data import globalVar
from .global_data import TASK_VARIABLE_MAP
from .global_data import MOBILE_DEVICE_MAP
from .global_data import GLOBAL_CONFIG_PASSWORD
from .global_data import SHIZAI_ELEMENT_DICT
from .global_data import run_module
self = SZEnv['rpa']
    
FLOW_QUEUE = []
# 开始
def flow_node_hsxAW():
    FLOW_QUEUE.append("flow_node_io5cd")
# 流程块1
def flow_node_io5cd():
    
    sz_count = 0
    overReTry = False
    while True:
        try:
            run_module({ "module_path": "flow_modules.io5cd" }, "main", SZEnv['rpa'], _sz_process_expr_="")
            break
        except Exception as e:
            _e = e
            sz_count += 1
            if sz_count > 0:
                overReTry = True
                _error  = SZEnv['rpa'].handling_error_info(e)
                break
    if overReTry:
        raise _e
    else:
        pass
    

#启动流程
def main(rpa):
    flow_node_hsxAW()
    while len(FLOW_QUEUE) > 0:
        flowName = FLOW_QUEUE.pop(0)
        eval(flowName + "()")
